This project was made by Cassandra Bleskachek for a research paper at the University of Minnesota. All original code; please don't reuse without contacting me first. Contact cassie.bleskachek@gmail.com with questions. 

To compile and run Mistress tests: 
"ocamlopt.opt -o runme game.ml util.ml search.ml play.ml test.ml main.ml"
"./runme" (this will take about an hour)